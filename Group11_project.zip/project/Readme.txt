# Sports Club Management System

A clean, modern web application built with **Flask** and **MySQL** to manage players, coaches, and registrations across multiple sports categories (Cricket, Football, and Kabaddi). It includes distinct portals for Administrators and Players, custom color schemes per sport, and automatic data logging via database triggers.

## 🚀 Features

### 👤 User Roles & Authentication
* **Admin Portal**: A master dashboard to manage club rosters.
    * **Credentials**: Username: `admin` | Password: `admin123`
* **Player Portal**: Secure login for registered athletes to view their profile, assigned coach, membership expiry, and fees.

### ⚽ Multi-Sport Management
* Dynamically manages 9 popular clubs across **Cricket**, **Football**, and **Kabaddi**.
* UI dynamically morphs color schemes based on the sport being viewed (Green for Cricket, Blue for Football, Orange for Kabaddi).
* Restricts positions/types and coach assignments to match the chosen sport context.

### 🛠️ CRUD Operations & Automation
* **Full CRUD**: Admins can add, read, update, and delete player records.
* **Database Constraints**: Prevents registration with expired memberships via SQL check constraints.
* **SQL Triggers**:
    * Automatically logs deleted player histories into a central `on_delete` audit table.
    * Automatically handles basic player login synchronization.

---

## 🛠️ Tech Stack

* **Backend:** Python (Flask)
* **Database:** MySQL
* **Frontend:** HTML5, CSS3 (Vanilla embedded layouts with Google Fonts), Jinja2 Templating
* **Database Driver:** `mysql-connector-python`

---

## 📁 Project Structure

```text
├── app.py             # Main Flask application file containing routing and business logic
├── database.sql       # Database schema creation script, tables, and automated triggers
└── templates/         # Jinja2 template folder
    ├── login.html     # Portal landing page for both Admins and Players
    ├── dashboard.html # Navigation hub sorting teams by sport type
    ├── players.html   # Main management interface for an individual club roster
    └── update.html    # Dedicated view editing form for a single player